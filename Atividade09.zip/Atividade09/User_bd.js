let usuarios = [
    
    { id: 1, nome: "João Carlos", cpf: 12345678999, telefone: 963214587, email: `joao@empresa.com` },
    { id: 2, nome: "Maria Silva", cpf: 98745612399, telefone: 985632147, email: `maria@empresa.com` },
    { id: 3, nome: "José Olibeira", cpf: 65478912399, telefone: 987456321, email: `jose@empresa.com` },
    { id: 4, nome: "Bruno Maia", cpf: 12378945699, telefone: 985263741, email: `bruno@empresa.com` },
    { id: 5, nome: "jardel Campos", cpf: 65498712399, telefone: 936528741, email: `jardel@empresa.com` },
    { id: 6, nome: "Fabio Silva", cpf: 98745632199, telefone: 912345678, email: `fabio@empresa.com` },
    { id: 7, nome: "Carlos Oliveira", cpf: 75336995199, telefone: 987123654, email: `carlos@empresa.com` },
    { id: 8, nome: "Abel Santos", cpf: 45632178999, telefone: 945612378, email: `abel@empresa.com` },
    { id: 9, nome: "Marcos Isabel", cpf: 85274196399, telefone: 978451263, email: `marcos@empresa.com` },
    { id: 10, nome: "Thiago Silva", cpf: 96325874199, telefone: 985632147, email: `thiago@empresa.com` },
  
];

module.exports = usuarios;