let Compras = ["Tomates", "Queijo", "Pão", "Cebolas", "Maçãs"];


Compras.sort((a, b) => a.localeCompare(b));
console.log(Compras);